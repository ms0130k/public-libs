/*********************************************************
 * NAME    : common-ibsheet 스크립트
 * DESC    : ibsheet 관련 공통 함수
 * VERSION : 1.0
 *********************************************************
 * 2024.12.24  김동현  최초 작성
 *********************************************************/

/*********************************************************
 * NAME   : gfn_InitGrid()
 * DESC   : 그리드(IBSheet) 레이아웃을 생성한다.
 * 			.loadSearchData(json데이터)로 데이터 출력 및 갱신
 * PARAM  : elId	- 그리드 출력할 Dom Id
 *          cols	- 컬럼 정보 배열
 *          options	- 부가 옵션(필수값 아님)
 * RETURN : 그리드 객체
 *
 * 2024.12.24  김동현  최초 작성
 *********************************************************/
function gfn_InitGrid(elId, cols, options = {}, data) {
	cols = gfn_SetGridColumn(cols);
	options = $.extend(true, gfn_GetGridDefaultOptions(), options);
	options.Cols =  cols;

	return IBSheet.create({
		el: elId,
		options: options,
		data: data ?? []
	});

	function gfn_SetGridColumn(cols = []) {
		const defaultValue = {
			Type: 'Text',
			CanSort: 1,
		};

		return cols.map(col => {
			col = { ...defaultValue, ...col };
			if (gfn_IsNull(col.Align)) {
				if (['Text'].includes(col.Type))
					col.Align = 'Left';
				else if (['Int', 'Float'].includes(col.Type))
					col.Align = 'Right';
				else
					col.Align = 'Center';
			}
			return col;
		});
	}

	function gfn_GetGridDefaultOptions() {
		return {
			Def : {
				Row : {
					CanFormula : 1
				}
			},
			Cfg: {
                MsgLocale: 'En',
				Style : 'IBSP',
				CanEdit: 1,
				CanSort: 1,
				EditSelect : 7,
				ColorState: 15,
				SearchMode: 0,
				Export: {
					LoadExcelUrl: '/api/cmn/excel/loadExcel',
					Down2ExcelUrl: '/api/cmn/excel/down2Excel',
				},
				IgnoreFocused: true,
				InfoRowConfig: {
					Visible: 1,
					Space: 'Bottom',
					Layout: 'Count',
				},
				NoDataMessage: 3,
				NoDataMiddle: 1
			}
		}
	}
}

/*********************************************************
 * NAME   : gfn_LoadExcelToGrid()
 * DESC   : 엑셀 파일 내용을 그리드(ibsheet)에 출력
 * PARAM  : gridObj		- 그리드(IBSheet) 객체
 * 			options		- IBSheet loadExcel 참고
 *
 * 2025.04.22  김동현  최초 작성
 *********************************************************/
function gfn_LoadExcelToGrid(gridObj, options = {}) {
	const csrfHeader = gfn_GetCsrfHeader();
	$.extend(true, options, {
		reqHeader: {
			[csrfHeader.key]: csrfHeader.value,
			'Nv-Menu-Cd': CURRENT_MENU_CD
		}
	});
	gridObj.loadExcel(options);
}

/*********************************************************
 * NAME   : gfn_ExportExcelFromGrid()
 * DESC   : 엑셀 파일 내용을 그리드(ibsheet)에 출력
 * PARAM  : gridObj		- 그리드(IBSheet) 객체
 * 			options		- IBSheet down2Excel 참고
 *
 * 2025.04.23  김동현  최초 작성
 *********************************************************/
function gfn_ExportExcelFromGrid(gridObj, options = {}) {
	const csrfHeader = gfn_GetCsrfHeader();
	$.extend(true, options, {
		reqHeader: {
			[csrfHeader.key]: csrfHeader.value,
			'Nv-Menu-Cd': CURRENT_MENU_CD
		}
	});
	gridObj.down2Excel(options);
}