/*********************************************************
 * NAME    : jQuery 공통 설정 스크립트
 * DESC    : jQuery 공통 설정
 * VERSION : 1.0
 *********************************************************
 * 2025.03.15  김동현  최초 작성
 *********************************************************/
(function () {
    $.ajaxSetup({
        headers: {
            'Nv-Page-Path': window.location.pathname,
        },
        beforeSend: (xhr) => {
            setHeader(xhr);
            spinnerSwitch.show();
        },
        complete: (xhr) => {
            gfn_ResizeWithScroll();
            spinnerSwitch.hide();
        },
        error: (xhr) => {
            const status = xhr.status;
            console.error(status);

            try {
                const body = JSON.parse(xhr.responseText);
                if (body.code === '999') {
                    gfn_Alert(body.message);
                } else {
                    gfn_Alert(gfn_GetMessage('msgUploadErrorServerError'));
                }
            } catch (e) {
                console.error('error on JSON.parse:', xhr.responseText);
                gfn_Alert(gfn_GetMessage('msgUploadErrorServerError'));
            }

            if (status === 401) {
                window.location.href = '/login';
            }
        }
    });

    $.widget('nova.dialogAlert', $.ui.dialog, {
        options: {
            modal: true,
            width: 450,
            classes: {
                'ui-dialog': '',
                'ui-dialog-titlebar': 'dialog-title-bar',
                'ui-dialog-title': 'dialog-title',
                'ui-dialog-titlebar-close': 'dialog-btn-close',
                'ui-dialog-content': '',
                'ui-dialog-buttonpane': '',
                'ui-dialog-buttonset': '',
            },
        },
        open() {
            // $('.ui-dialog-titlebar-close').hide();
            return this._super();
        },
    });

    $.widget('nova.dialogPopup', $.ui.dialog, {
        options: {
            modal: true,
            closeOnEscape: false,
            classes: {
                'ui-dialog': '',
                'ui-dialog-titlebar': '',
                'ui-dialog-title': '',
                'ui-dialog-titlebar-close': '',
                'ui-dialog-content': '',
                'ui-dialog-buttonpane': 'ui-helper-hidden',
                'ui-dialog-buttonset': '',
            }
        },
    });

    const spinnerSwitch = (function () {
        let ajaxCounter = 0;
        return {
            show() {
                ajaxCounter++;
                $('#spinnerContainer').show();
            },
            hide() {
                ajaxCounter = Math.max(ajaxCounter - 1, 0);
                if (ajaxCounter === 0) {
                    $('#spinnerContainer').hide();
                }
            },
        }
    })();

    function setHeader(xhr) {
        const csrfHeader = gfn_GetCsrfHeader();
        xhr.setRequestHeader('Nv-Menu-Cd', CURRENT_MENU_CD);
        xhr.setRequestHeader(csrfHeader.key, csrfHeader.value);
    }
})();