/*********************************************************
 * NAME    : common-dialog.js
 * DESC    : 공통 다이얼로그(popup, modal) 호출
 * VERSION : 1.0
 *********************************************************
 * 2025.03.07  김동현  최초 작성
 *********************************************************/
const gfn_Dialog = {}
gfn_Dialog.url = (function () {
	const load = function ({url, winName, width, height, requestParams = {}, openType = 'popup', callback, options = {}}) {
		console.assert(url && winName && width && height);
		requestParams = requestParams || {};
		requestParams.windowOpenType = openType;
		options = options || {};

        const baseUrl = extractBaseUrl(url);
        mergeUrlParamsToRequestParams(url, requestParams);
		setMenuCd(requestParams);
		setOptionsToRequestParam(requestParams, options);
		winName = transFormWinName(winName, openType);

		const callObject = {
			url: baseUrl,
			winName,
			requestParams,
			callback,
			options: {...options, width, height},
		};

		return openProcess(callObject, openType);
	};

	const close = function (winName) {
		gfn_Dialog.modalMap.remove(winName);
		$(`#${winName}`).dialogPopup('destroy').remove();
	};

	const openPopup = function ({
									url,
									winName,
									requestParams = {},
									callback,
									options = {width: 100, height: 100,}
								} = {}) {
		const left = (screen.width - options.width) / 2;
		const top = ((screen.height - options.height) / 2) - 30;
		options = {...options, left, top};
		const optionsStr = Object.entries(options)
			.map(([key, value]) => `${key}=${value}`)
			.join(',');

		const popupWindow = window.open('', winName, optionsStr);

		gfn_SubmitForm({
			action: url, target: winName, params: requestParams,
		});

		gfn_GetTopMainWindow().gfn_Dialog.callback.regist(winName, {callback, requestParams});

		popupWindow.focus();
		return popupWindow;
	};

	const openModal = function ({
									url,
									winName,
									requestParams = {},
									callback,
									options = {width: 100, height: 100, title: ''}
								} = {}) {
		const modal = `<div id="${winName}" style="display: none; padding: 0;"><iframe name="${winName}" style="width: 100%; height: 99%;"></iframe></div>`;
		$('body').append(modal);

		const dialog = $(`#${winName}`).dialogPopup({
			...options,
			close() {
				const winName = this.getAttribute('id');
				gfn_Dialog.modalMap.remove(winName);
				$(this).dialogPopup('destroy').remove();
			},
		});

		gfn_SubmitForm({
			action: url, target: winName, params: requestParams,
		});

		gfn_GetTopMainWindow().gfn_Dialog.callback.regist(winName, {callback, requestParams});
		gfn_Dialog.modalMap.set(winName, dialog);

		return dialog;
	};

	const openTab = function ({
								  url,
								  winName,
								  requestParams = {},
								  callback,
								  options = {width: 100, height: 100, title: ''}
							  } = {}) {

		const tabId = `${requestParams.menuCd}-${winName}`;
		gfn_Tab.addTab({
			title: options.title,
			id: tabId,
			options: {
				contents: {
					type: 'code',
					contents: `<iframe name="${winName}" style="width: 100%; height: 99%;"></iframe>`
				},
			},
		});

		gfn_SubmitForm({
			action: url, target: winName, params: requestParams,
		});

		gfn_GetTopMainWindow().gfn_Dialog.callback.regist(winName, {callback, requestParams});
	};

	return {
		load, close, openTab
	}

	function extractBaseUrl(url) {
		const [baseUrl,] = url.split('?');
		return baseUrl;
	}

	function mergeUrlParamsToRequestParams(url, requestParams) {
		const [,queryString] = url.split('?');
		new URLSearchParams(queryString).forEach((value, key) => requestParams[key] = value);
	}

	function setMenuCd(requestParams) {
		if (!requestParams.menuCd) requestParams.menuCd = CURRENT_MENU_CD;
	}

	function setOptionsToRequestParam(requestParams, options) {
		if (options.scrollbars === 'yes' || Number(options.scrollbars) === 1) {
			requestParams.scrollbars = 1;
		} else {
			requestParams.scrollbars = 0;
		}
	}

	function transFormWinName(winName, openType) {
		return `${openType}-${winName}`;
	}

	function openProcess(callObject, openType) {
		if (openType === 'popup')
			return openPopup(callObject);
		if (openType === 'modal')
			return openModal(callObject);

		gfn_GetTopMainWindow().gfn_Dialog.url.openTab(callObject);
	}
})();

gfn_Dialog.dom = function (domId, options = {}) {
    const $dialog = $(`#${domId}`).dialogPopup({
        autoOpen: false,
        title: '제목',
        ...options,
    });

    const open = function () {
        $dialog.dialogPopup('open');
    };

	const close = function () {
		$dialog.dialogPopup('close');
	};
    return {open, close};
};

gfn_Dialog.callback = (function () {
	if (!gfn_ThisWindowIsTopMain()) return;

	const callbackInfos = new Map();//<winName: string, {callback: function, params: object}>

	const invoke = function (winName, response) {
		const callbackInfo = callbackInfos.get(winName);
		if (!callbackInfo) return;

		const {callback, requestParams} = callbackInfo;
		callback({
			calledParam: requestParams,
			returnParam: response,
		});

		callbackInfos.delete(winName);
	};

	const regist = function (winName, {callback, requestParams}) {
		callbackInfos.set(winName, {callback, requestParams});
	};
	
	return {regist, invoke}
})();

gfn_Dialog.modalMap = (function () {
	const modalMap = new Map();
	const set = (winName, modalObj) => {
		modalMap.set(winName, modalObj);
	};
	const get = winName => modalMap.get(winName);
	const remove = winName => modalMap.delete(winName);
	return {set, get, remove};
})();

window['gfn_Dialog'] = gfn_Dialog;