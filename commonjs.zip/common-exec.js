/*********************************************************
 * NAME    : 공통 실행 스크립트
 * DESC    : 공통 실행
 * VERSION : 1.0
 *********************************************************
 * 2025.05.12  김동현  최초 작성
 *********************************************************/
window.addEventListener('beforeunload', () => {
    // TODO 세션 끊겼을 때 문제 있어서 보류
    // if (!gfn_ThisWindowIsTopMain()) {
    //     gfn_GetTopMainWindow().gfn_SetAlrimiCnt();
    // }
});

$(function () {
    if (WINDOW_OPEN_TYPE === 'modal') {
        $('.popup-content-title').hide();
    }
    gfn_ResizeWithScroll();
    gfn_SetCustomTooltipEvent();
});