/*********************************************************
 * NAME    : 공통 스크립트
 * DESC    : 업무에서 사용하는 공통 스크립트 (작성법 : gfn_[동사][명사], 동사 첫글자 대문자)
 * VERSION : 1.0
 *********************************************************
 * 2025.03.07  장민훈  최초 작성
 *********************************************************/

/*********************************************************
 공통 변수 영역 [START]
 *********************************************************/
var DATE_SEPERATOR = "-"; // 날짜 구분선 2025-02-03
var TIME_SEPERATOR = ":"; // 시간 구분선 17:30:30
var DEFAULT_SEARCH_PERIOD = 3; // 날짜 from to 검색시 기본 조회 단위(월)
var DEFAULT_IBSHEET_DATE_FORMAT = "yyyy-MM-dd";
/*********************************************************
 공통 변수 영역 [END]
 *********************************************************/

/*********************************************************
 * NAME   : gfn_GetMessage()
 * DESC   : 메시지 프로퍼티스 정보를 조회
 * PARAM  : key		- 메시지(템플릿) 키
 *          args	- 메시지 템플릿에 삽입될 메시지
 * RETURN : 메시지, 자바의 메시지 properties 복제본
 *
 * 2025.1.9  김동현  최초 작성
 *********************************************************/
const gfn_GetMessage = (key, args = []) => {
    console.assert(key);
    const resource = IS_EN ? MESSAGE_EN : MESSAGE_KO;
    const template = resource[key] || key;

    return args.reduce((result, arg, i) => {
        const pattern = new RegExp(`\\{${i}\\}`);
        return result.replace(pattern, arg);
    }, template);
};

/*********************************************************
 * NAME   : gfn_GetMessageUsingKeyArgs()
 * DESC   : 메시지 프로퍼티스 정보를 조회
 * PARAM  : key		    - 메시지(템플릿) 키
 *          args	    - 메시지 템플릿에 삽입될 메시지 키
 *          toLowerCase - 삽입될 메시지들을 모두 소문자로 할지 (기본값 false)
 * RETURN : 메시지, 자바의 메시지 properties 복제본
 *
 * 2025.1.20  김동현  최초 작성
 *********************************************************/
const gfn_GetMessageUsingKeyArgs = (key, args = [], toLowerCase = false) => {
    console.assert(key);
    const resource = IS_EN ? MESSAGE_EN : MESSAGE_KO;
    const template = resource[key] || key;

    return args.reduce((result, arg, i) => {
        let converted = gfn_GetMessage(arg);
        if (toLowerCase) converted = converted.toLowerCase();
        const pattern = new RegExp(`\\{${i}\\}`);
        return result.replace(pattern, converted);
    }, template);
};

/*********************************************************
 * NAME   : gfn_SubmitForm()
 * DESC   : submit 수행
 * PARAM  : method	: http method, 기본값 POST
 *          action  : submit url
 *          params  : submit 파라미터 Object
 * RETURN : void
 *
 * 2025.1.20  김동현  최초 작성
 *********************************************************/
const gfn_SubmitForm = ({method = 'POST', action, target = '_blank', params = {}}) => {
    const form = document.createElement('form');

    form.action = action;
    form.method = method;
    form.target = target;

    params['_csrf'] = document.querySelector('meta[name=_csrf]').content;
    Object.entries(params).forEach(([key, value]) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = value;
        form.appendChild(input);
    });

    document.body.appendChild(form);
    form.submit();
    form.remove();
};

/*********************************************************
 * NAME   	: gfn_OpenWindow(theURL, winName, w, h, callback, optionObj, paramObj, openType)
 * DESC   	: 팝업 윈도우를 오픈한다.
 * PARAM  	: theURL   	 	- 팝업으로 오픈할 파일의 경로
 *            winName   	- 팝업 윈도우 명
 *            w         	- 팝업 width
 *            h         	- 팝업 height
 *            callback 		- 팝업에서 콜백 실행시 호출할 함수
 *            option    	- 파업/모달에서 사용할 추가 옵션 오브젝트
 *                            팝업: scrollbars, resizable 등(window api 참고)
 *                            모달: draggable, resizablet 등(jquery dialog ui 참고)
 *            paramObj  	- URL 호출 파라미터 오브젝트
 *            openType		- 윈도우 유형, popup / modal / tab. 기본값: popup
 * RETURN 	: 팝업: 팝업 윈도우 객체
 *            모달: 모달 jquery 객체
 * 호출예시 : const theURL = '/Common/ApprovalRead/viewApprovalReadPopup';
 *            const winName = 'ApprovalReadPopup';
 *            const w = 800;
 *            const h = 600;
 *            const callback = function (res) {
 *                console.log(res.calledParam); //paramObj
 *                console.log(res.returnParam); //팝업창 결과
 *              };
 *            const option = {
 *              //팝업, 모달
 *              scrollbars: [1 또는 0][yes 또는 no]
 *              //모달
 *              title: '제목', //기본값: ''
 *              draggable: false, //기본값: true
 *              //탭
 *              title: '탭제목', //필수
 *            };
 *            const paramObj = {
 *                pjtCod : pjtCod,
 *                menuCod : menuCod,
 *                aprvListTyp : aprvListTyp,
 *                dataIdx : dataIdx,
 *                aprvIdx : aprvIdx
 *              };
 *              const openType = 'modal';
 *            호출유형1: gfn_OpenWindow(theURL, winName, w, h);
 *            호출유형2: gfn_OpenWindow(theURL, winName, w, h, callback, option, paramObj);
 *            호출유형3: gfn_OpenWindow(theURL, winName, w, h, callback, null, paramObj);
 *            호출유형4: gfn_OpenWindow(theURL, winName, w, h, callback, null, paramObj, openType);
 *
 * 2024.12.24  장민훈  최초 작성
 *********************************************************/
function gfn_OpenWindow(theURL, winName, w, h, callback, optionObj, paramObj, openType = 'popup') {
    return gfn_Dialog.url.load({
        url: theURL,
        winName: winName,
        width: w,
        height: h,
        requestParams: paramObj,
        callback: callback,
        options: optionObj,
        openType: openType,
    });
}

/*********************************************************
 * NAME   : gfn_CloseWindow()
 * DESC   : 팝업(윈도우 팝업, 모달) 닫기 및 콜백 실행
 * PARAM  : [선택]withCallback	    - 콜백함수 실행 여부, 기본값 true
 *          [선택]returnParam		- 콜백함수에 전달할 파라미터
 * RETURN : void
 * 호출예시 : gfn_CloseWindow()				- 닫기 및 콜백함수 실행. 콜백 결과 파라미터는 없음
 *            gfn_CloseWindow(true)			- 닫기 및 콜백함수 실행. 콜백 결과 파라미터는 없음
 *            gfn_CloseWindow(true, param)	- 닫기 및 콜백함수 실행. 콜백 결과 파라미터 전달
 *            gfn_CloseWindow(false)		- 닫기 및 콜백함수 실행하지 않음.
 *
 * 2025.03.07  김동현  최초 작성
 *********************************************************/
function gfn_CloseWindow(withCallback = true, returnParam = {}) {
    const winName = window.name;
    if (withCallback) {
        gfn_GetTopMainWindow().gfn_Dialog.callback.invoke(winName, returnParam);
    }

    gfn_GetTopMainWindow().gfn_SetAlrimiCnt();

    if (gfn_ThisWindowIsModal()) {
        window.parent.gfn_Dialog.url.close(winName);
    } else if (gfn_ThisWindowIsTab()) {
        gfn_GetTopMainWindow().gfn_Tab.removeTab();
    } else {
        window.close();
    }
}

/*********************************************************
 * NAME   : gfn_RelocatePage(url, params)
 * DESC   : 페이지 이동
 * PARAM  : [필수] url			: 요청 경로
 *          [선택] params		: 요청 파라미터
 *          [선택] option        : 창 크기 ex) {width: 1000, height: 800}
 * RETURN : void
 *
 * 2025.3.11  김동현  최초 작성
 *********************************************************/
function gfn_RelocatePage(url, params = {}, option = {}) {
    const baseUrl = extractBaseUrl(url);
    mergeUrlParamsToRequestParams(url, params);
    setMenuCd();

    //TODO 공통 함수 사용 가능하지 않나
    const $form = $(`<form method="post" action="${baseUrl}"></form>`);
    params['_csrf'] = document.querySelector('meta[name=_csrf]').content;
    Object.entries(params)
        .map(([key, value]) => $(`<input type="hidden" name="${key}">`).val(value))
        .forEach(el => $form.append(el));
    $form.appendTo('body').submit();

    if (option.width && option.height) {
        const width = option.width;
        const height = option.height;
        window.resizeTo(width, height);
        const left = (screen.width - width) / 2;
        const top = (screen.height - height) / 2;
        window.moveTo(left, top);
    }

    function extractBaseUrl() {
        const [baseUrl,] = url.split('?');
        return baseUrl;
    }

    function mergeUrlParamsToRequestParams() {
        const [, queryString] = url.split('?');
        new URLSearchParams(queryString)
            .forEach((value, key) => params[key] = value);
    }

    function setMenuCd() {
        if (!params.menuCd) params.menuCd = CURRENT_MENU_CD;
    }
}

/*********************************************************
 * NAME   : gfn_Alert(msg, type, callback)
 * DESC   : type에 따른 경고창을 생성하고 확인 버튼을 클릭시 callback 함수를 호출한다.
 * PARAM  : [필수] msg				: 경고창에 보여줄 메시지
 *          [선택] type / callback	: 경고 유형 / callback
 *          [선택] callback		: callback 함수
 * RETURN : boolean
 *
 * 2025.1.22  장민훈  최초 작성
 *********************************************************/
const gfn_Alert = (function () {
    const alertQueue = [];
    const TITLES = {};
    TITLES.N = gfn_GetMessage('ttl.alert.noti');
    TITLES.W = gfn_GetMessage('ttl.alert.warning');
    TITLES.E = gfn_GetMessage('ttl.alert.error');

    let alertIsOpen = false;
    const showAlert = (msg, type = 'N', callback) => {
        if (gfn_IsNull(type)) {
            type = 'N';
        }

        if (typeof type === 'function') {
            callback = type;
            type = 'N';
        }
        type = type.toUpperCase();

        alertQueue.push({msg, type, callback});
        if (!alertIsOpen) {
            processAlert();
        }
    };
    const processAlert = () => {
        if (alertQueue.length === 0) {
            alertIsOpen = false;
            return;
        }

        alertIsOpen = true;
        const {msg, type, callback} = alertQueue.shift();

        setArea();
        $('#alertWindow').html(msg.replace(/\n/g, '<br>')).dialogAlert({
            title: TITLES[type],
            buttons: [{
                text: gfn_GetMessage('btnOk'),
                click() {
                    $(this).dialogAlert('close');
                }
            }],
            close() {
                if (callback) callback();
                processAlert();
            },
        });
    };
    const setArea = () => {
        if (!$('#alertWindow')[0])
            $('body').append(`<div id="alertWindow" style="display: none"></div>`);
    };

    return showAlert;
})();

/*********************************************************
 * NAME   : gfn_Confirm(sMsg,callback)
 * DESC   : 확인창을 생성하고 확인/취소 버튼을 클릭시 callback 함수를 호출한다.
 * PARAM  : sMsg	  : 확인창에 보여줄 메시지
 *          callback  : callback 함수 (인자로 true/false 리턴)
 * RETURN : boolean
 *
 * 2025.1.22  장민훈  최초 작성
 *********************************************************/
var ___bConfirmDupChk = false;
const gfn_Confirm = (sMsg, callback) => {
    //TODO 수정합시다.
    if (typeof callback === "function") {
        callback(confirm(sMsg));
    }

    return;


    var bReturn = false;
    var title = "확인";
    var type = "";

    //중복방지
    if (___bConfirmDupChk) return;
    ___bConfirmDupChk = true;

    //"<b>Alert</b>\n Application Call dialog push"
    if (gfn_IsNull(sMsg)) sMsg = "";

    dialog.push({
        type: type
        , title: title
        , body: sMsg
        , buttons: [
            {
                buttonValue: "Yes"
                , buttonClass: "Blue"
                , onClick: function () {
                    ___bConfirmDupChk = false;
                    bReturn = true;

                    if (typeof callback === "function") {
                        callback(bReturn);
                    }
                }
            },
            {
                buttonValue: "No"
                , buttonClass: "" //"Blue"
                , onClick: function () {
                    ___bConfirmDupChk = false;
                    bReturn = false;

                    if (typeof callback === "function") {
                        callback(bReturn);
                    }
                }
            }
        ]
    });

    return bReturn;
};

/*********************************************************
 * NAME   : gfn_SetDefaultCalendarHandler
 * DESC   : 기본 달력 호출
 * 사용방법 :  $("#search_start_dd").on("click", gfn_SetDefaultCalendarHandler );
 * RETURN :
 *
 * 2025-03-28  성은호  최초 작성
 *********************************************************/
const gfn_SetDefaultCalendarHandler = (e) => {
    let $target = $(e.target);
    const option = {
        Date: gfn_IsNull($target.val()) ? new Date() : $target.val(),
        Format: DEFAULT_IBSHEET_DATE_FORMAT
    };
    let callback = (rtn) => {
        $target.val(IBSheet.dateToString(rtn, DEFAULT_IBSHEET_DATE_FORMAT));
    }
    IBSheet.showCalendar(option, {Mouse: 1}, callback);
}

/*********************************************************
 * NAME   : gfn_SetSearchCalendar
 * DESC   : 검색기간이 설정되는 start, end 달력
 * 사용방법 : gfn_SetSearchCalendarHandler ( 'search_start_dd' ,   '#search_end_dd'  ,  -90 );
 * parameter: startElId : 검색 start 날짜 element id (String)
 *             endElId : 검색 end 날짜 element id (String)
 *             addDay : diff day (Number)
 * RETURN :
 *
 * 2025-03-28  성은호  최초 작성
 *********************************************************/
const gfn_SetSearchCalendarHandler = (startElId, endElId, addDate) => {
    let $startDtEl = $("#" + startElId);
    let $endDtEl = $("#" + endElId);

    // element 존재 여부 체크
    if ($startDtEl.length == 0) {
        console.error("날짜 start element id 가 정확히 지정되지 않았습니다");
        return;
    }
    if ($endDtEl.length == 0) {
        console.error("날짜 end element id 가 정확히 지정되지 않았습니다");
        return;
    }
    if (gfn_IsNull(addDate)) {
        console.error("diff day 가 정확히 지정되지 않았습니다");
        return;
    }
    if (!gfn_IsNum(addDate)) {
        console.error("diff day는 숫자형식입니다");
        return;
    }
    $("#" + startElId + ", #" + endElId).on("click", gfn_SetDefaultCalendarHandler);

    let today = new Date();
    let baseDdStr, addedDdStr;

    baseDdStr = today.getFullYear() + DATE_SEPERATOR + gfn_LPad(2, today.getMonth() + 1) + DATE_SEPERATOR
        + gfn_LPad(2, today.getDate());
    today.setDate(today.getDate() + addDate);

    addedDdStr = today.getFullYear() + DATE_SEPERATOR + gfn_LPad(2, today.getMonth() + 1) + DATE_SEPERATOR
        + gfn_LPad(2, today.getDate());

    if (addDate > 0) {
// start: 오늘
// end : 오늘 + addDay
        $startDtEl.val(baseDdStr);
        $endDtEl.val(addedDdStr);
    } else {
// start : 오늘 - addDay
// ene : 오늘
        $endDtEl.val(baseDdStr);
        $startDtEl.val(addedDdStr);
    }
}

/*********************************************************
 (deprecated)
 * NAME   : gfn_SetSearchDatePicker
 * DESC   : 검색 조건 date picker 날짜 세팅
 * PARAM  :
 *        period: 개월수 (optional: default: 3개월 )
 *        startObj: 시작 element id (optional: default: 'search_start_dt')
 *        endObj: 종료 element id (optional: default: 'search_end_dt')
 *        baseDateStr: 기준일 YYYYMMDD 형식 ( optional:  default: 오늘 )
 * RETURN :
 *
 * 2025-02-03  성은호  최초 작성
 *********************************************************/
const gfn_SetSearchDatePicker = (period, startElId, endElId, baseDateStr) => {
    if (gfn_IsNull(period) || !gfn_IsNum(period)) {
        period = DEFAULT_SEARCH_PERIOD;
    }

    if (gfn_IsNull(startElId)) {
        startElId = "search_start_dt";
    }

    if (gfn_IsNull(endElId)) {
        endElId = "search_end_dt";
    }

    let $startDtEl = $("#" + startElId);
    let $endDtEl = $("#" + endElId);

    if ($startDtEl.length == 0 || $endDtEl.length == 0) {
        return;
    }

    if (!gfn_IsFunction("datetimepicker")) {
        return;
    }
    $startDtEl.datetimepicker({
        datepicker: true, timepicker: false
        , format: "Y" + "-" + "m" + "-" + "d"
    });
    $endDtEl.datetimepicker({
        datepicker: true, timepicker: false
        , format: "Y" + "-" + "m" + "-" + "d"
    });
    let baseDate;
    if (gfn_IsNull(baseDateStr) || !gfn_IsValidDate(baseDateStr)) {
        baseDate = new Date();
    } else {
        const dateRegExp = /(\d{4})(\d{2})(\d{2})/;
        const match = baseDateStr.match(dateRegExp);

        if (!match) return false;
        const [_, year, month, day] = match;
        baseDate = new Date(`${year}-${month}-${day}`);
    }

    let endDate = baseDate.getFullYear() + DATE_SEPERATOR + gfn_LPad(2, baseDate.getMonth() + 1) + DATE_SEPERATOR
        + gfn_LPad(2, baseDate.getDate());

    baseDate.setMonth(baseDate.getMonth() - period);
    let startDate = baseDate.getFullYear() + DATE_SEPERATOR + gfn_LPad(2, baseDate.getMonth() + 1) + DATE_SEPERATOR
        + gfn_LPad(2, baseDate.getDate());

    $startDtEl.val(startDate);
    $endDtEl.val(endDate);
};

/*********************************************************
 * NAME   : [TODO] clearFrmSearchBox
 * DESC   : 검색 조건 초기화
 * PARAM  :
 * RETURN :
 *
 * 2025-02-03  성은호  최초 작성
 *********************************************************/
const gfn_ClearFrmSearchBox = () => {


};

/*********************************************************
 * NAME   : gfn_IsNull(str)
 * DESC   : NULL 또는 빈 문자열인지 체크하여 true/false 를 리턴한다.
 * PARAM  : str         : 체크할 문자열
 * RETURN : rtnObj      : json Object
 * 호출예시 : gfn_IsNull(str);
 *
 * 2025.01.22  김동현  최초 작성
 *********************************************************/
function gfn_IsNull(str) {
    if (str == null)
        return true;
    if (['undefined', 'NaN', 'null'].includes(str))
        return true;
    return !new String(str).toString().trim();
}

/*********************************************************
 * NAME   : gfn_IsFunction
 * DESC   : 공통 - 함수 존재여부
 * PARAM  :
 *        func: 함수ID(String)
 * RETURN : boolean
 *
 * 2025-02-03  성은호  최초 작성
 *********************************************************/
const gfn_IsFunction = (func) => {
    if (gfn_IsNull(func)) {
        return false;
    }

    if (typeof ($.fn[func]) == "function" || typeof (func) == "function") {
        //함수존재
        return true;
    }

    return false;
};
const gfn_IsNum = (s) => {
    //숫자형문자여부
    try {
        return (s == new String(parseFloat(s)) ? true : false);
    } catch (e) {
        return false;
    }
};


function gfn_Focus(sId, form) {
    if (form != undefined && form != null)
        $(form).find('#' + sId).trigger("focus");
    else
        $('#' + sId).trigger("focus");
}

/*********************************************************
 * NAME   : gfn_GetColumnData(nodeId)
 * DESC   : 특정 영역의 data-col-id 속성을 가진 input, select를 탐색,
 *          data-col-id 속성 값을 key로 노드의 value를 value로 하는 Object를 생성하여 반환
 * PARAM  : nodeId	- 탐색할 영역 노드 ID
 * RETURN : {
 *                [data-cold-id의 값]: [node의 value]
 *                ...
 *          }
 *
 * 2024.12.24  김동현  최초 작성
 *********************************************************/
function gfn_GetColumnData(nodeId) {
    const result = {};
    const area = document.getElementById(nodeId);
    if (!area) {
        console.error(`element with id "${nodeId}" not found`);
        return result;
    }
    const elements = area.querySelectorAll('input[data-col-id], select[data-col-id], textarea[data-col-id]');
    elements.forEach((el) => {
        const colId = el.dataset.colId;
        if (colId && el.value) {
            result[colId] = el.value;
        }
    });
    return result;
}

/*********************************************************
 * NAME   : gfn_GetColumnDataToQueryString(nodeId)
 * DESC   : 특정 영역의 data-col-id 속성을 가진 input, select를 탐색,
 *          data-col-id 속성 값을 key로 노드의 value를 value로 하는 쿼리스트링 문자열 반환
 * PARAM  : nodeId	- 탐색할 영역 노드 ID
 * RETURN : '[data-cold-id의 값]=[node의 value]&...'
 *
 * 2024.12.24  김동현  최초 작성
 *********************************************************/
function gfn_GetColumnDataToQueryString(nodeId) {
    const columnData = gfn_GetColumnData(nodeId);
    return new URLSearchParams(columnData).toString();
}

/*********************************************************
 * NAME   : gfn_ClearColumnData(nodeId, options)
 * DESC   : 특정 영역의 data-col-id 속성을 가진 input, select 값을 삭제
 * PARAM  : [필수] nodeId	- 탐색할 영역 노드 ID
 *          [선택] options - {
 *              exclusions: 제외할 목록
 *          }
 *
 * 2024.12.24  김동현  최초 작성
 *********************************************************/
function gfn_ClearColumnData(elId, options = {
    exclusions: [],
}) {
    const area = document.getElementById(elId);
    if (!area) {
        console.error(`element with id "${elId}" not found`);
        return;
    }
    const inputs = area.querySelectorAll('input[data-col-id]');
    inputs.forEach(el => {
        if (!options.exclusions.includes(el.dataset.colId)) {
            el.value = '';
        }
    });
    const selects = area.querySelectorAll('select[data-col-id]');
    selects.forEach(el => {
        const option = el.querySelector('option');
        if (option) {
            el.value = option.value;
        }
    });
}


/*********************************************************
 * Properties Toggle
 * 손영식 , 2018.07.23
 *
 * ex)
 *      $(selector).toggleAttr("required");
 *      $(selector).toggleAttr("required", true);
 *      $(selector).toggleAttr("required", false);
 *
 ******************************************************** */
$.fn.extend({
    toggleAttr: function (attr, turnOn) {
        var justToggle = (turnOn === undefined);
        return this.each(function () {
            if ((justToggle && !$(this).is("[" + attr + "]")) ||
                (!justToggle && turnOn)) {
                $(this).attr(attr, attr);
            } else {
                $(this).removeAttr(attr);
            }
        });
    }
});

/*********************************************************
 * NAME   : gfn_SetIframeAutoHeightDefault(iframeId, heightOffset)
 * DESC   : iframe의 높이를 설정한다.
 *          window resize, 최초 iframe 로딩 후 등 iframe 내부 컨텐츠에 따라 높이가 자동 조절된다.
 * PARAM  : iframeId	  : iframe id
 *          heightOffset  : 하단 여백 offset
 *
 * 2025.2.14  장민훈  최초 작성
 *********************************************************/
function gfn_SetIframeAutoHeightDefault(iframeId, heightOffset) {
    var windowResizeFunction = function (resizeFunction, iframe) {
        $(window).resize(function () {
            resizeFunction(iframe);
        });
    };

    var height = heightOffset;
    if (typeof (height) == "undefined" && height == null) {
        height = 0;
    }

    $('#' + iframeId).iframeAutoHeight({
        heightOffset: height
        , triggerFunctions: [
            windowResizeFunction
        ]
    });
}

/*********************************************************
 * NAME   : gfn_GetSysCodeList(grpCd)
 * DESC   : 공통코드를 조회하여 리턴한다.(동기식 호출)
 * PARAM  : [필수] grpCd	  : 공통그룹코드 (예:APRV_LINE_APRV_LINE_CND)
 *          [선택] cdTyp   : 공통그룹유형 (예:sysDetlCdMst)
 *
 * 2025.2.26  김태호  최초 작성
 *********************************************************/
function gfn_GetSysCodeList(pjtCd, grpCd, cdTyp = 'sysDetlCdMst') {
    let rtnData;
    $.ajax({
        type: 'POST',
        data: {pjtCd: pjtCd, grpCd: grpCd, cdTyp: cdTyp},
        url: '/api/cmn/code/selectCdList',
        dataType: 'JSON',
        async: false,
        success: function (data) {
            rtnData = data;
        }
    }).done(console.log);
    return rtnData;
}

/*********************************************************
 * NAME   : gfn_SetCodeComboBind(elementId, pjtCd, cdTyp, grpCd, selectNm, delCd, type, callback, dispCol, initVal)
 * DESC   : 공통코드를 조회하여 Select Box/Checkbox/Radio Group을 만든다.
 * PARAM  : [필수] elementId  : 타겟 요소 id
 *          [필수] pjtCd      : 프로젝트코드 (예:0000)
 *          [필수] cdTyp      : 공통그룹유형 (예:sysDetlCdMst)
 *          [부분필수] grpCd   : 공통그룹코드 (예:APRV_LINE_APRV_LINE_CND), cdTyp이 sysDetlCdMst인 경우에는 필수
 *          [선택] selectNm   : 기타 조건이 많아 Name 입력된 값으로 설정됨 (value는 ''임)
 *          [선택] delCd      : 출력시 코드 제외대상(예: "H" or ["A","H"])
 *          [선택] type       : 'S' 셀렉트박스(기본값), 'C' 체크박스, 'R' 라디오, 'SNC' 셀렉트박스(name에 코드 안보이는 유형)
 *          [선택] callback   : 후 처리 Callback 함수
 *          [선택] dispCol    : 'cmnCdNm'(기본값) 표출될 text 컬럼
 *          [선택] initVal    : ''(기본값) 선택될 value
 *          [선택] {}         : 추가 파라미터, DB 전달용 외에 함수 내부에서 쓰기위한 용도도 가능함.
 *                {
 *                   extParam : etcCol1=A&etcCol2=ABC&etcCol3=test....  // 공통코드 조회시 추가 조회조건 설정값
 *                }       
 * 예제 : gfn_SetCodeComboBind('docKndCd', CURRENT_PJT_CD, 'sysDetlCdMst', 'DOC_TYP', gfn_GetMessage('lineSelect'));
 * 2025.2.26  김태호  최초 작성
 *********************************************************/
function gfn_SetCodeComboBind(elementId, pjtCd, cdTyp, grpCd, selectNm, delCd, type = 'S', callback = null, dispCol = 'cmnCdNm', initVal = '', {extParam} = {}) {
    if (gfn_IsNull(elementId)) return;
    if (gfn_IsNull(pjtCd)) pjtCd = CURRENT_PJT_CD;
    if (gfn_IsNull(type)) type = 'S';
    if (gfn_IsNull(dispCol)) dispCol = 'cmnCdNm';

    let html = '';
    let arrDelCdList = [];

    //첫 번째로 보여질 옵션 (선택, 전체 등등)
    if ((type === 'S' || type === 'SNC') && !gfn_IsNull(selectNm)) {
        html += `<option value="">${selectNm}</option>`;
    }

    //제외 대상 코드
    if (!gfn_IsNull(delCd)) {
        if (Array.isArray(delCd)) {
            arrDelCdList = delCd;
        } else {
            arrDelCdList = [delCd];
        }
    }

    $.ajax({
        type: 'POST',
        data: {pjtCd: pjtCd, grpCd: grpCd, cdTyp: cdTyp, extParam: extParam},
        url: '/api/cmn/code/selectCdList',
        dataType: 'JSON',
        success: function (data) {
            for (const e of data) {
                if (arrDelCdList.includes(e.cmnCd)) continue;
                if (type === 'C') {
                    html += `<label class="checkbox_label">
                                 <input type="checkbox" id="${elementId}_${e.cmnCd}" value="${e.cmnCd}">
                                 <span class="h-checkbox-img"></span><span class="h-checkbox-text">${e[dispCol]}</span>
                             </label>`;
                } else if (type === 'R') {
                    html += `<label class="radio">
                                 <input type="radio" name="${elementId}" value="${e.cmnCd}">
                                 <span class="h-radio"></span>${e[dispCol]}
                             </label>`;
                } else {
                    if (type === 'S') {
                        html += `<option value="${e.cmnCd}">[${e.cmnCd}] ${e[dispCol]}</option>`;
                    } else {
                        html += `<option value="${e.cmnCd}">${e[dispCol]}</option>`;
                    }
                }
            }

            if (type === 'C') {
                html = '<div class="check-box">' + html + '</div>';
            }

            $('#' + elementId).attr('data-combo-grpcd', grpCd);
            $('#' + elementId).empty();
            $('#' + elementId).html(html);

            if (type === 'R') {
                $('input[name=' + elementId + ']').first().prop('checked', true);
            }

            //init value 처리
            if (!gfn_IsNull(initVal)) {
                switch (type) {
                    case "R" :
                        $('input[name=' + elementId + '][value=' + initVal + ']').prop('checked', true);
                        break;
                    case "C" :
                        //$('#' + elementId).find('input[type=checkbox][value=' + initVal + ']').prop('checked', true);
                        break;
                    default:
                        $('#' + elementId).val(initVal);
                        break;
                }
            }

            if (!gfn_IsNull(callback)) {
                if (typeof callback === "function") {
                    callback(elementId, data);
                }
            }
        }
    }).done(console.log);

    return true;
}

/*********************************************************
 * NAME   : gfn_SetCodeComboJoinBind(elementId,pjtCd,grpCd,selectNm)
 * DESC   : 공통코드를 조회하여 Select Box에 출력한다.
 * PARAM  : [필수] elementId  : Select Box ID (String)
 *          [필수] grpCd     : 공통그룹코드 (예:APRV_LINE_APRV_LINE_CND)
 *          [필수] cdTyp     : 공통그룹유형 (default:sysDetlCdJoin)
 *          [선택] selectNm    : 기타 조건이 많아 Name 입력된 값으로 설정됨 (value는 '' 임)
 *          [선택] delCd     : 출력시 코드 제외대상(예: "H" or ["A","H"])
 *          [선택] callback : 후 처리 Callback
 * 예제 : gfn_SetComboJoinBind("selSample","0000","TRADE","A","─── All ───")
 * 2025.2.26  김태호  최초 작성
 *********************************************************/
function gfn_SetCodeComboJoinBind(elementId, pjtCd, cdTyp, grpCd, detlCd, selectNm, delCd, callback) {
    if (gfn_IsNull(elementId)) return;
    let html = '';
    let arrDelCdList = [];

    //첫 번째로 보여질 옵션 (선택, 전체 등등)
    if (!gfn_IsNull(selectNm)) {
        html += `<option value=''>${selectNm}</option>`;
    }

    //제외 대상 코드
    if (!gfn_IsNull(delCd)) {
        if (Array.isArray(delCd)) {
            arrDelCdList = delCd;
        } else {
            arrDelCdList = [delCd];
        }
    }

    $.ajax({
        type: 'GET',
        data: {pjtCd: pjtCd, grpCd: grpCd, detlCd: detlCd, cdTyp: cdTyp},
        url: '/api/sys/code/selectCmnCodeJoinList',
        dataType: 'JSON',
        success: function (data) {
            let sJoinGrpCd = '';
            if (data.length > 0) sJoinGrpCd = data[0].joinGrpCd;

            for (const e of data) {
                if (arrDelCdList.includes(e.detlCd)) continue;
                html += `<option value='${e.detlCd}'>${e.detlCdNm}</option>`;
            }

            $('#' + elementId).attr('data-combo-grpcd', sJoinGrpCd);
            $('#' + elementId).html(html);

            if (!gfn_IsNull(callback)) {
                if (typeof callback === 'function') {
                    callback($('#' + elementId), data);
                }
            }
        }
    }).done(console.log);

    return true;
}

/*********************************************************
 * NAME   : gfn_SetModalDom(domId, options)
 * DESC   : DOM ID 영역을 모달로 설정
 * PARAM  : [필수] domId		: DOM ID
 *          options {
 *              [선택] title	: 상단 제목
 *              [선택] width    : 너비
 *              [선택] height   : 높이
 *          }
 * RETURN : {
 *     open : 모달 열기 함수
 *     close: 모달 닫기 함수
 * }
 *
 * 2025.3.4  김동현  최초 작성
 *********************************************************/
function gfn_SetModalDom(domId, options = {}) {
    return gfn_Dialog.dom(domId, options);
}

/*********************************************************
 * NAME   : gfn_ShowCal(targetId, rangeIds, callbackFunc, option)
 * DESC   : 날짜 Input에 IBSheet 달력 출력
 * PARAM  : [필수] targetId		: 달력이 보여지게 할 Input Id
 *                                ex) 'startDt'
 *          [선택] rangeIds      : 날짜 범위 선택인 경우 시작 날짜 Input Id와 종료 날짜 Input Id 배열
 *                                ex) ['startDt', 'endDt']
 *          [선택] callbackFunc  : 콜백 함수
 *          [선택] option        : 기타 커스텀 옵션 ex) {Format: 'yyyy-MM'}
 * RETURN : void
 *
 * 2025.4.15  변서영  최초 작성
 *********************************************************/
function gfn_ShowCal(targetId, rangeIds = [], callbackFunc = null, option = null) {
    const dateInput = document.getElementById(targetId);
    let initValue = new Date(dateInput.value);
    let format = DEFAULT_IBSHEET_DATE_FORMAT;
    let calOption = {
        Date: initValue.toString() === 'Invalid Date' ? new Date() : initValue,
        Format: format,
        Class: 'IBSPPick'
    };

    if (rangeIds != null && rangeIds.length == 2) {
        const startId = rangeIds[0];
        const endId = rangeIds[1];

        calOption.OnCanEditDate = (date) => {
            const dateStr = IBSheet.dateToString(date, format);
            if (targetId == startId) {
                const end = $('#' + endId).val();
                if (end) {
                    return dateStr <= end;
                }
            } else {
                const start = $('#' + startId).val();
                if (start) {
                    return start <= dateStr;
                }
            }
        }
    }

    if (option != null) {
        if (!gfn_IsNull(option.Format)) {
            format = option.Format;
        }
        calOption = {...calOption, ...option};
    }

    function callback(rtn) {
        dateInput.value = IBSheet.dateToString(rtn, format);

        if (callbackFunc != null && typeof callbackFunc === "function") { //콜백함수 호출 //2025-05-12 김진 추가
            callbackFunc(IBSheet.dateToString(rtn, format));
        }
    }

    IBSheet.showCalendar(calOption, {Mouse: 1}, callback);
}

/*********************************************************
 * NAME   : gfn_Logout()
 * DESC   : 로그아웃 실행
 *          CSRF 방지를 위해 GET method로 로그아웃 실행 막음
 *
 * 2025.4.17  김동현  최초 작성
 *********************************************************/
function gfn_Logout() {
    gfn_SubmitForm({
        action: '/logout',
        target: '_self',
    });
}

/*********************************************************
 * NAME   : gfn_GetCsrfHeader()
 * DESC   : CSRF 헤더 키와 토큰 값 획득
 * RETURN : {
 *              key: '헤더 키',
 *              value: '헤더 값'
 *          }
 *
 * 2025.4.17  김동현  최초 작성
 *********************************************************/
function gfn_GetCsrfHeader() {
    const key = document.querySelector('meta[name=_csrf_header]').content;
    const value = document.querySelector('meta[name=_csrf]').content;
    return {
        key, value
    }
}

/*********************************************************
 * NAME   : gfn_SetAlrimiCnt()
 * DESC   : 알리미 개수 표기
 *
 * 2025.4.17  김동현  최초 작성
 *********************************************************/
function gfn_SetAlrimiCnt() {
    if (!CURRENT_PJT_CD) return;

    $.ajax({
        type: 'POST',
        url: '/api/cmn/alrimi/selectAlrimiList',
    }).done(res => {
        const cnt = res.reduce((acc, cur) => acc + cur.cnt, 0);
        const txtCnt = cnt > 999 ? '999+' : cnt;
        $('.js-noti-cnt').text(txtCnt);
    });
}

/*********************************************************
 * NAME   : gfn_SetColumnData(nodeId, data)
 * DESC   : data의 key로 data-col-id 속성을 가진 태그를 탐색,
 *          태그의 value, textContent, title(툴팁) 등에 삽입
 * PARAM  : nodeId	- 탐색할 영역 노드 ID
 *
 * 2025.5.15  김동현  최초 작성
 *********************************************************/
function gfn_SetColumnData(elId, data) {
    const area = document.getElementById(elId);
    Object.entries(data).forEach(([key, value]) => {
        const element = area.querySelector(`[data-col-id=${key}]`);
        if (!element) return;

        element.title = String(value);

        const tag = element.tagName.toLowerCase();
        if (tag === 'input' || tag === 'textarea') {
            element.value = value;
        } else {
            element.textContent = value;
        }
    });
}

/*********************************************************
 * NAME   : gfn_SetCustomTooltipEvent()
 * DESC   : 커스텀 툴팁의 hover 이벤트를 추가
 *
 * 2025.5.15  김동현  최초 작성
 *********************************************************/
function gfn_SetCustomTooltipEvent() {
    $('.tooltip-trigger i')
      .hover(
        function (e) {
            $('.custom-tooltip')
              .css({top: e.pageY + 10, left: e.pageX + 10})
              .fadeIn();
        },
        function () {
            $('.custom-tooltip').fadeOut();
        }
      )
      .mousemove(function (e) {
          $('.custom-tooltip').css({top: e.pageY + 10, left: e.pageX + 10});
      });
}

/*********************************************************
 * NAME   : gfn_GetCodeNm(grpCd, detlCd, includeCodeYn)
 * DESC   : 공통코드 상세코드명 조회
 * PARAM  : [필수] grpCd	         : 그룹코드 ex) 'CMN_CP_CD'
 *          [필수] detlCd		 : 상세코드 ex) 'CP-P1'
 *          [선택] includeCodeYn  : 상세코드명 앞에 코드값 보여줄지
 *                                ex) 'Y'인 경우 [CP-P1] Piping 반환
 *                                    'N'인 경우 Piping 반환
 * RETURN : String
 *
 * 2025.5.19  변서영  최초 작성
 *********************************************************/
function gfn_GetCodeNm(grpCd, detlCd, includeCodeYn = 'Y') {
    let codeNm = '';
    $.ajax({
        url: '/api/cmn/code/selectCdNm',
        data: {grpCd, detlCd, includeCodeYn},
        type: 'POST',
        async: false,
        dataType: 'JSON',
        success: (res) => {
            codeNm = res.codeName;
        }
    });
    return codeNm;
}