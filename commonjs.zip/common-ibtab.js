/*********************************************************
 * NAME    : common-ibtab.js
 * DESC    : IBTab 초기화 스크립트
 * VERSION : 1.0
 *********************************************************
 * 2025.04.14  김동현  최초 작성
 *********************************************************/

/*********************************************************
 * NAME   : gfn_Tab()
 * DESC   : IBTab 기능 제공 즉시 실행 함수
 * RETURN : {
 *              init: 초기화
 *              addTab: 탭 추가
 *              getActiveTabId: 현재탭 ID 반환
 *          } 
 *
 * 2024.12.24  김동현  최초 작성
 *********************************************************/
const gfn_Tab = (function () {
    let mainTabObj = null;
    
    function init({
                      tabId = 'pageTabContainer',
                      contentId = 'pageContentContainer',
                      options = {}} = {}) {
        const tabs = document.getElementById(tabId);
        const contents = document.getElementById(contentId);
        const baseOptions = $.extend(true, {
            widthTabBar: '100%',
            widthContents: '100%',
            heightContents: '100%',
            themes: {
                tabs: 'simple_blue',
                contents: 'simple_blue',
            },
            contextMenu: {
                enable: false,
            },
        }, options);

        createIBTab(tabs, contents, 'ibTabId', baseOptions);
        mainTabObj = window['ibTabId'];
    }

    function addTab({title, id, url, options = {}}) {
        console.assert(mainTabObj !== null);

        if (mainTabObj.findTabId(id)) {
            mainTabObj.goToTab(mainTabObj.findTabId(id).getIndex());
            return;
        }
        const baseOptions = {
            tabs: {
                title, id,
                focus: true,
            },
            contents: {
                type: 'iframe',
                contents: url
            },
        };
        $.extend(true, baseOptions, options);
        mainTabObj.addTab(baseOptions);
    }

    function getActiveTabId() {
        console.assert(mainTabObj !== null);

        return mainTabObj.tabs.getActiveTab().getId();
    }

    function removeTab() {
        mainTabObj.removeTab(mainTabObj.tabs.getActiveTab().getIndex());
    }

    function removeAllTabs() {
        mainTabObj.removeAllTabs();
    }

    function setOptions(options) {
        mainTabObj.setOptions(options)
    }

    return {
        init,
        addTab,
        getActiveTabId,
        removeTab,
        removeAllTabs,
        setOptions
    }
})();

window['gfn_Tab'] = gfn_Tab;

