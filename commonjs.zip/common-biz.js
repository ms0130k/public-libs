/*********************************************************
 * NAME    : 업무공통 스크립트
 * DESC    : 업무에서 사용하는 공통 스크립트 (작성법 : cfn_[동사][명사], 동사 첫글자 대문자)
 * VERSION : 1.0
 *********************************************************
 * 2025.03.07  장민훈  최초 작성
 *********************************************************/

/*********************************************************
 * NAME   : cfn_OpenAttachWindow(paramObj, openType)
 * DESC   : 첨부파일 조회 팝업 오픈
 * PARAM  : [필수] paramObj : 첨부파일을 가져오기 위한 파라미터 오브젝트 (dataIdx 필수)
 *                           ex) {dataIdx: 1}
 * RETURN : void
 *
 * 2025.3.13  변서영  최초 작성
 *********************************************************/
function cfn_OpenAttachWindow(paramObj) {
    const param = {
        url: '/view/cmn/popup/popAttach',
        winName: 'popAttach',
        width: 900,
        height: 320,
        requestParams: paramObj,
        openType: 'modal',
        callback: null,
        options: {title: gfn_GetMessage('txtAttachment')}
    }

    gfn_Dialog.url.load(param);
}

/*********************************************************
 * NAME   : cfn_GetUserSignImageViewerUrlPath(userId)
 * DESC   : 사용자 서명 이미지 url 가져오기
 * PARAM  : [필수] filePath		: 파일경로 >> 해당 파일 경로는 java에서 FileGroup enum 을 사용해서
 *                                FileGroup.USER_SIGN.getViewerUrl("userId", false, "fileNm")로 변환한 값을 넘겨줘야함
 *                                ex)"user-sign/22086/오지영_사인.jpg"
 *          [필수] menuCd		: 메뉴 cd
 * RETURN : url path
 *
 * 2025.3.18  성은호  최초 작성
 *********************************************************/
function cfn_GetUserSignImageViewerUrlPath(filePath, menuCd) {
    if (gfn_IsNull(filePath)) {
        console.error("filePath 값 필수");
        return "";
    }

    if (gfn_IsNull(menuCd)) {
        console.error("menuCd 값 필수");
        return "";
    }

    return "/api/cmn/file/imageViewer?url=" + filePath + "&menuCd=" + menuCd;
}

/*********************************************************
 * NAME   : cfn_GetDextImageViewerUrlPath(userId)
 * DESC   : dext로 업로드된 이미지 파일 url 가져오기
 * PARAM  : [필수] filePath		: java에서 atchUsecase.selectImageUrlFromFilePath로 가공을 거친 file path
 *          [필수] menuCd		: 메뉴 cd
 * RETURN : url path
 *
 * 2025.3.18  성은호  최초 작성
 *********************************************************/
function cfn_GetDextImageViewerUrlPath(filePath, menuCd) {
    if (gfn_IsNull(filePath)) {
        console.error("filePath 값 필수");
        return "";
    }

    if (gfn_IsNull(menuCd)) {
        console.error("menuCd 값 필수");
        return "";
    }

    return "/api/cmn/file/dextImageViewer?url=" + filePath + "&menuCd=" + menuCd;
}

/*********************************************************
 * NAME   : cfn_GetSysCodeGridEnum({pjtCd, cdTyp, grpCd})
 * DESC   : 공통 코드를 그리드(IBSheet) Enum 타입으로 변경하여 반환
 * PARAM  : [필수] grpCd          : 공통그룹코드 (예: APRV_LINE_APRV_LINE_CND)
 *          [선택] cdTyp          : 공통그룹유형 (예: sysDetlCdMst)
 *          [선택] pjtCd          : 프로젝트 코드
 *          [선택] sep            : Enum 구분자 (예: |책임|부장)
 *          [선택] format         : Enum 출력 포맷, ${필드키} 사용
 *                                  예) [${cmnCd}]${cmnCdNm}
 *          [선택] useBlank       : 빈값 사용 여부, 기본값: true
 *          [선택] blankText      : 빈값에 출력할 텍스트, 빈문자열 사용 가능. 미설정시 txtSelect 사전값 사용
 * RETURN : {
 *              EnumKeys: '|BJ|BN'
 *              Enum: '|부사장|책임'
 *          }
 *
 * 2025.4.24  김동현  최초 작성
 *********************************************************/
function cfn_GetSysCodeGridEnum({
                                    grpCd,
                                    cdTyp = 'sysDetlCdMst',
                                    pjtCd = CURRENT_PJT_CD,
                                    sep = '|',
                                    format = '[${cmnCd}] ${cmnCdNm}',
                                    useBlank = true,
                                    blankText
                                } = {}) {
    blankText = blankText === undefined || blankText === null
      ? gfn_GetMessage('txtSelect')
      : blankText;
    const data = gfn_GetSysCodeList(pjtCd, grpCd, cdTyp);
    const initValue = useBlank
      ? {EnumKeys: sep, Enum: sep + blankText}
      : {EnumKeys: '', Enum: ''};
    const regex = /\$\{([^}]+)}/g;

    return data.reduce((acc, cur) => {
        acc.EnumKeys += sep + cur.cmnCd;
        acc.Enum += sep + format.replace(regex, (m, k) => cur[k]);
        return acc;
    }, initValue);
}

/*********************************************************
 * NAME   : cfn_SetCanEditFalse(cols, exName)
 * DESC   : 그리드 column CanEdit 속성을 0(false)으로 설정
 * PARAM  : [필수] cols        : 그리드 column 배열
 *          [선택] exNameList  : 수정 가능하게 할 컬럼 Name 배열 ex) ['chk', 'status']
 *                              체크박스는 수정 가능해야 하기 때문에 기본값 ['chk']
 * RETURN : cols
 * EX     : gridObj = gfn_InitGrid('gridList', cfn_SetCanEditFalse(cols), options);
 *
 * 2025.3.13  변서영  최초 작성
 *********************************************************/
function cfn_SetCanEditFalse(cols, exNameList = ['chk']) {
    for (let e of cols) {
        if (exNameList != null && exNameList.length > 0) {
            if (exNameList.includes(e['Name'])) continue;
        }
        e['CanEdit'] = 0;
    }
    return cols;
}

/*********************************************************
 * NAME   : cfn_setChkDisable(gridObj, chkColumnName, regUserId, aprKndColumnName)
 * DESC   : 전달받은 그리드오브젝트의 체크박스를 조건에 맞게 비활성화 처리
 *          그리드 체크박스 활성화 조건
 *          1.관리자인 경우
 *          2.그리드데이터의 결재상태가 'TEMP'이면서 작성자인 경우(전자결재 있는 경우)
 *          3.작성자인 경우(전자결재 없는 경우)
 * PARAM  : [필수] gridObj        : 그리드 객체
 *          [필수] chkColumnName  : checkbox 컬럼명
 *          [필수] regUserIdColumnName  : 등록자ID 컬럼명
 *          [선택] aprKndColumnName  : 결재상태 컬럼명 (전자결재 있는 경우 필수)
 *
 * 2025.4.29  장민훈  최초 작성
 *********************************************************/
function cfn_SetChkCanEditFalseByStatus(gridObj, chkColumnName, regUserIdColumnName, aprKndColumnName = null) {

    if (gfn_IsNull(gridObj)) return;
    if (gfn_IsNull(chkColumnName)) return;
    if (gfn_IsNull(regUserIdColumnName)) return;

    let Rows = gridObj.getDataRows();
    for (let i = 0; i < Rows.length; i++) {
        let regUserIdVal = gridObj.getValue(Rows[i], regUserIdColumnName);

        if (!gfn_IsNull(aprKndColumnName)) { //전자결재 있는경우
            let aprKndVal = gridObj.getValue(Rows[i], aprKndColumnName);

            if (!cfn_IsPsblEditOrDel(regUserIdVal, aprKndVal)) {
                gridObj.setAttribute(Rows[i], chkColumnName, "CanEdit", 0, 0);
            }
        } else { //전자결재 없는 경우
            if (!cfn_IsPsblEditOrDel(regUserIdVal)) {
                gridObj.setAttribute(Rows[i], chkColumnName, "CanEdit", 0, 0);
            }
        }
    }
}

/*********************************************************
 * NAME   : cfn_IsPsblEditOrDel(regUserId, aprKnd)
 * DESC   : 수정 또는 삭제가 가능한 조건
 *          1.관리자인 경우
 *          2.그리드데이터의 결재상태가 'TEMP'이면서 작성자인 경우(전자결재 있는 경우)
 *          3.작성자인 경우(전자결재 없는 경우)
 * PARAM  : [필수] regUserId        : 등록자ID
 *          [선택] aprKnd  : 결재상태 (전자결재 있는 경우 필수)
 * RETURN : 수정 또는 삭제 가능하면 true 그렇지 않으면 false
 *
 * 2025.4.29  장민훈  최초 작성
 *********************************************************/
function cfn_IsPsblEditOrDel(regUserId, aprKnd = null) {
    let rtnVal = true;

    if (USER_MENU_AUTH == "A") return rtnVal;

    if (!gfn_IsNull(aprKnd)) { //전자결재 있는경우
        if (!(aprKnd == "TEMP" && CURRENT_USER_ID == regUserId)) {
            rtnVal = false;
        }
    } else { //전자결재 없는 경우
        if (CURRENT_USER_ID != regUserId) {
            rtnVal = false;
        }
    }

    return rtnVal;
}

/*********************************************************
 * NAME   : cfn_GetUrl(fileType , fileNm, pUserId)
 * DESC   : 파일타입과 파일명을 전달받아서 IMG URL을 만들어서 리턴
 * PARAM  : [필수] fileType : 파일유형 (user-profile, user-sign)
 *          [필수] fileNm  : 파일명
 *          [옵션] pUserId  : 사용자ID
 * RETURN : 파일 URL 경로
 *
 * 2025.4.30  장민훈  최초 작성
 *********************************************************/
function cfn_GetUrl(fileType, fileNm, pUserId) {
    let sRtn = "";
    let sBasicUrl = "/api/cmn/file/imageViewer?url=";
    if (!gfn_IsNull(fileType) && !gfn_IsNull(fileNm)) {
        let pathUserId = gfn_IsNull(pUserId) ? CURRENT_USER_ID : pUserId;

        // imageViewer 경로 + 파일 타입 + 사용자 정보 + 파일명
        sRtn = sBasicUrl + "/" + fileType + "/" + pathUserId + "/" + fileNm + "&menuCd=" + CURRENT_MENU_CD;
    }
    return sRtn;
}

/*********************************************************
 * NAME   : cfn_SetErrorPage(status)
 * DESC   : error status에 따른 오류 페이지 화면 설정
 * PARAM  : [필수] status : 오류 유형(400, 401, 500...)
 *
 * 2025.05.02  김동현  최초 작성
 *********************************************************/
function cfn_SetErrorPage(status) {
    const txtStatus = document.getElementById('txtStatus');
    const statusChars = status.toString().split('');
    txtStatus.innerHTML = `${statusChars[0]}<span>${statusChars[1]}</span>${statusChars[2]}`;
    document.getElementById('txtDesc').textContent = gfn_GetMessage('error.page.desc.' + status);

    const btnHomeOrClose = document.getElementById('btnHomeOrClose');

    if (gfn_ThisWindowIsPopup())
        btnHomeOrClose.textContent = gfn_GetMessage('error.page.btn.close');
    else
        btnHomeOrClose.textContent = gfn_GetMessage('error.page.btn.gotohome');
    if (gfn_ThisWindowIsIframe()) {
        btnHomeOrClose.remove();
        return;
    }

    btnHomeOrClose?.addEventListener('click', e => {
        if (gfn_ThisWindowIsPopup()) {
            window.close();
            return;
        }
        window.location.href = '/';
    });
}

/*********************************************************
 * NAME   : cfn_PopCommonReadInfo(readParam)
 * DESC   : 열람이력 팝업 호출(defualt modal)
 * PARAM  : [필수] readParam : readParam.dataIdx key
 *
 * 2025.05.19  김진  최초 작성
 *********************************************************/
function cfn_PopCommonReadInfo(readParam) {
    let sId = 'popCommonReadInfo';
    let url = '/view/cmn/popup/popCommonReadInfo';
    let optionObj = {title:gfn_GetMessage('txtChecked1') };

    readParam.logType = gfn_IsNull(readParam.logType) ? "R" : readParam.logType;
    readParam.listType =  gfn_IsNull(readParam.listType) ? "L" : readParam.listType;
    readParam.openType =  gfn_IsNull(readParam.openType) ? "modal" : readParam.openType;
    readParam.width =  gfn_IsNull(readParam.width) ? 700 : readParam.width;
    readParam.height =  gfn_IsNull(readParam.height) ? 600 : readParam.height;
    readParam.callBack = gfn_IsFunction(readParam.callBack) ? readParam.callBack : null;

    gfn_OpenWindow(url, sId, readParam.width, readParam.height ,readParam.callBack ,optionObj, readParam, readParam.openType);
}

/*********************************************************
 * NAME   : cfn_PopApprovalInfo(readParam)
 * DESC   : 결재이력이력 팝업 호출(defualt modal)
 * PARAM  : [필수] aprvParam : aprvParam.dataIdx key
 *
 * 2025.05.20  김진  최초 작성
 *********************************************************/
function cfn_PopApprovalInfo(aprvParam) {
    let sId = `popApprovalInfo`;
    let url = `/view/cmn/popup/popApprovalInfo`;
    let optionObj = {title:gfn_GetMessage('txtApprovalInfo') };

    aprvParam.openType =  gfn_IsNull(aprvParam.openType) ? "modal" : aprvParam.openType;
    aprvParam.width =  gfn_IsNull(aprvParam.width) ? 700 : aprvParam.width;
    aprvParam.height =  gfn_IsNull(aprvParam.height) ? 600 : aprvParam.height;
    aprvParam.callBack = gfn_IsFunction(aprvParam.callBack) ? aprvParam.callBack : null;

    gfn_OpenWindow(url, sId, aprvParam.width, aprvParam.height ,aprvParam.callBack ,optionObj, aprvParam, aprvParam.openType);
}

/*********************************************************
 * NAME   : cfn_SetCommonCodeGirdOnDataLoad(options)
 * DESC   : 공통 코드 그리드 데이터 로드시, 체크박스 체크 및 비활성화 처리
 * PARAM  : [필수] gridObj : 그리드 객체
 *          [필수] cdColNm : 기준 코드 컬럼명
 *          [선택] options : {
 *              chkColNm        : 체크 박스 컬럼명
 *              multiSelYnNodeId: 다중 선택 가능 여부(Y/N) Dom ID
 *              chkCdListNodeId  : 체크 대상 목록 문자열 Dom ID
 *              disbCdListNodeId : 체크 박스 비활성화 목록 문자열 Dom ID
 *          }
 *
 * 2025.05.21  김동현  최초 작성
 *********************************************************/
function cfn_SetCommonCodeGirdOnDataLoad(gridObj, cdColNm, {
                                             chkColNm = 'chk',
                                             chkCdListNodeId = 'chkCdList',
                                             disbCdListNodeId = 'disbCdList',
                                         } = {}) {
    const paramChkCdList = document.getElementById(chkCdListNodeId)?.value;
    const paramDisbCdList = document.getElementById(disbCdListNodeId)?.value;

    const chkCdList = paramChkCdList.split(',');
    const disbCdList = paramDisbCdList.split(',');

    gridObj.getDataRows().forEach(row => {
        if (chkCdList && chkCdList.some(chkCd => chkCd === row[cdColNm])) {
            row[chkColNm] = 1;
        }
        if (disbCdList && disbCdList.some(disbCd => disbCd === row[cdColNm])) {
            gridObj.setAttribute(row, chkColNm, 'CanEdit', 0, 0);
        }
    });
}

/*********************************************************
 * NAME   : cfn_SetStringDateFormat(dateVal, format)
 * DESC   : 날짜 형식 변경 처리
 * PARAM  : [필수] dateVal : ex) '20250521'
 *          [선택] format : ex) 'yyyy-MM-dd' default
 * 2025.05.20  김진  최초 작성
 *********************************************************/
function cfn_SetStringDateFormat(dateVal, format){
    if(gfn_IsNull(dateVal) || dateVal.length < 6){
        return '';
    }

    var regExp = /[\{\}\[\]\/?/.;:|/)*~`!^\-_+<>@\#$%^\\\=\(\'\"]/gi;
    dateVal =dateVal.replace(regExp,'').replaceAll(' ','');//특수문자 공백 제거

    if(dateVal.length % 2 === 1){//입력받은 dateVal 형태가 2025521 인경우 처리
        var year = dateVal .substring (0,4);
        var month = dateVal.substring (4,5);
        var dd = dateVal .substring (5);

        if(month === '0'){
            month = dateVal.substring (4,6);
            dd = dateVal .substring (6);
        }

        if(Number(month) < 10 && month.length === 1){
            month =  '0'+month;
        }

        dateVal = year+month+dd;
    }

    if(dateVal.length === 8){//유형별 날짜형태로 치환
        dateVal = dateVal.replace(/(\d{4})(\d{2})(\d{2})/,'$1-$2-$3')
        format = gfn_IsNull(format) ? 'yyyy-MM-dd' : format;
    }else if(dateVal.length === 10){
        dateVal = dateVal.replace(/(\d{4})(\d{2})(\d{2})(\d{2})/,'$1-$2-$3 $4')+':00';
        format = gfn_IsNull(format) ? 'yyyy-MM-dd HH' : format;
    }else if(dateVal.length >= 12){
        dateVal = dateVal.substring(0,12).replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/,'$1-$2-$3 $4:$5')
        format = gfn_IsNull(format) ? 'yyyy-MM-dd HH:mm' : format;
    }

    return gfn_FormatDatetime(dateVal,format);
}