/*
  ----------------------------------------------------------------------
   NAME    : common-utils.js
   DESC    : common util
   VERSION : 1.0
  ----------------------------------------------------------------------
   2025-02-04  성은호  최초 작성
  -----------------------------------------------------------------------
*/


/*********************************************************
 * NAME   : gfn_GetUniqueValue()
 * DESC   : 고유 문자열을 생성한다.
 *
 * 2025.1.22  김동현  최초 작성
 *********************************************************/
const gfn_GetUniqueValue = (function () {
    let lastTimestamp = 0;
    let sameCount = 0;
    return (prefix = 'nv') => {
        const now = Date.now();
        if (now === lastTimestamp) {
            sameCount++;
        } else {
            sameCount = 0;
            lastTimestamp = now;
        }
        return `${prefix}-${now}${sameCount}`;
    }
})();

/*********************************************************
 * NAME   : gfn_CreateReactiveMap()
 * DESC   : 추가, 삭제시 이벤트를 설정할 수 있는 맵을 생성한다.
 * PARAM  : onPut		- 요소 추가시 동작할 함수(key, value를 파라미터로 받는다)
 *          onRemove	- 요소 삭제시 동작할 함수(key, value를 파라미터로 받는다)
 * RETURN : 맵 조작 객체
 * 			요소 추가: put(key, value)
 * 			요소 삭제: remove(key)
 * 			전체 요소 삭제: removeAll()
 * 			전체 요소 조회: read()
 *
 * 2025.1.9  김동현  최초 작성
 *********************************************************/
function gfn_CreateReactiveMap ({ onPut, onRemove }) {
    if (typeof onPut !== 'function') {
        throw new TypeError('onPut must be a function');
    }
    if (typeof onRemove !== 'function') {
        throw new TypeError('onRemove must be a function');
    }

    const map = new Map();
    return {
        put(key, value) {
            const isNew = !map.has(key);
            map.set(key, value);
            if (isNew) {
                onPut(key, value);
            }
        },
        remove(key) {
            if (map.has(key)) {
                const removedValue = map.get(key);
                map.delete(key);
                onRemove(key, removedValue);
            }
        },
        removeAll() {
            const entries = Array.from(map.entries());
            map.clear();
            entries.forEach(([key, value]) => {
                onRemove(key, value);
            });
        },
        read() {
            return Array.from(map.entries());
        },
        keys() {
            return Array.from(map.keys());
        }
    };
}

/*********************************************************
 * NAME   : gfn_CreateTagMap()
 * DESC   : 버튼 형식의 태그를 생성/삭제/읽기할 맵 생성
 * PARAM  : selector	- 태그 생성할 영역 선택자
 * 						  e.g. '#id', '#id .class'
 *			{
 *			 	buttonClass	- 버튼(태그)에 추가할 html class
 *			 				  기본값: 'btn btn-outline-success btn-sm pdm-tag'
 *			}
 * RETURN : 태그맵 관리 객체 {
 *			put(key, label, data) 	- key: 맵 저장 식별자, label: 태그(버튼) 라벨, data: read시 돌려받을 데이터
 *			remove(key)		- key에 해당하는 태그 삭제
 *			removeAll()		- 모든 태그 삭제
 *			read()			- 모든 태그 정보 읽기
 *							  형식: [[key1, data1], [key2, data2]...]
 * }
 *
 * 2025.1.20  김동현  최초 작성
 *********************************************************/
function gfn_CreateTagMap(selector, {
    buttonClass = 'btn-name'
} = {}) {

    const idPrefix = `tag${gfn_GetUniqueValue()}`;
    const reactiveMap = gfn_CreateReactiveMap({
        onPut: (key, {label}) => {
            if (typeof key !== 'string') throw new TypeError('key must be string');

            let tag= `<button type="button" class="${buttonClass}" id="${idPrefix}-${key}">${label}<i></i></button>`;
            $(selector).append(tag);
            $(`#${idPrefix}-${key}`).on('click', () => {
                reactiveMap.remove(key);
            });
        },
        onRemove: (key) => {
            $(`#${idPrefix}-${key}`).remove();
        },
    });

    return {
        put: (key, label, data) => {
            if (typeof key !== 'string') throw new TypeError('key must be string');
            reactiveMap.put(key, {label, data});
        },
        remove: reactiveMap.remove,
        removeAll: reactiveMap.removeAll,
        read: reactiveMap.read,
        keys: reactiveMap.keys
    };
}

/* date 관련 util */
var DATE_SEPERATOR = "-"; // 날짜 구분선 2025-02-03
/*********************************************************
 * NAME   : dateToString
 * DESC   : Date 형식을 string 으로 return
 * PARAM  :
 *        date: Date 타입 (required)
 *        separator : 구분자 ( optional : default: 공통 DATE_SEPARATOR 사용 )
 * RETURN :
 *
 * 2025-02-04  성은호  최초 작성
 *********************************************************/
const gfn_GetTodayDate = (separator) => {
    if (gfn_IsNull(separator)) {
        separator = DATE_SEPERATOR;
    }
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}` + separator + `${month}` + separator + `${day}`;
};
const gfn_IsValidDate = (text) => {
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    if (!regex.test(text)) return false;

    const date = new Date(text);
    return !isNaN(date.getTime());
};

/*********************************************************
 * NAME   : gfn_ObjToString
 * DESC   : obj 형식을 string 으로 리턴
 * PARAM  : obj (required)
 * RETURN : string
 *
 * 2025-02-03  성은호  최초 작성
 *********************************************************/
const gfn_ObjToString = (obj) => {
    let str = '';
    for (let p in obj) {
        if (obj.hasOwnProperty(p)) {
            str += p + '::' + obj[p] + '\n';
        }
    }
    return str;
};
/*********************************************************
 * NAME   : 숫자앞에 자리수만큼 특정문자 채우기
 * DESC   : 숫자앞에 자리수만큼 특정문자(default: 0) 채우기
 * PARAM  : len : 길이 (required)
 *          res: 입력문자 (required)
 *          pad: 채울문자 (optional: default: '0')
 * RETURN :
 *
 * 2025-02-03  성은호  최초 작성
 *********************************************************/
const gfn_LPad = (len, res, pad) => {
    let str = '' + res;
    if (gfn_IsNull(pad)) {
        pad = '0'
    }

    while (len > str.length) {
        str = pad + str;
    }
    return str;
};

/*********************************************************
 * NAME   : gfn_GetStrLen()
 * DESC   : 문자열의 byte 수를 구한다.
 * PARAM  : str - byte 수를 구하고자 하는 문자열.
 * RETURN : 문자열의 byte 수
 *
 * 2025.1.23  장민훈  최초 작성
 *********************************************************/
const gfn_GetStrLen = (str) => {
    var rtnLen = 0;

    //for (var i = 0; i < str.length; i++) {
        //str.charCodeAt(i) > 255 ? rtnLen += 2 : rtnLen += 1;
    //}
    rtnLen = str.length;
    return rtnLen;
};

/*********************************************************
 * NAME   : gfn_CheckDate()
 * DESC   : 날짜 형식을 체크한다.
 * PARAM  : str - 날짜 문자열.
 * RETURN : 문자열의 byte 수
 *
 * 2025.3.13  장민훈  최초 작성
 *********************************************************/
function gfn_CheckDate(str)
{
    var yy,mm,dd,ny,nm,nd;
    var arr_d;

    if(str.length <= 6) {

        var m = parseInt(str.substring(4,6));
        return (m >= 1 && m <= 12);
    }

    if(str.length != 8) {
        return false;
    }
    yy = str.substring(0,4);
    mm = str.substring(4,6);
    dd = str.substring(6,8);

    if(mm < '10')
        mm = mm.substring(1);

    if(dd < '10')
        dd = dd.substring(1);

    ny = parseInt(yy);
    nm = parseInt(mm);
    nd = parseInt(dd);

    if(!(Number(yy)) || (ny < 1000) || (ny>9999)) {

        return false;
    }
    if(!(Number(mm)) || (nm < 1) || (nm > 12)) {

        return false;
    }
    arr_d = new Array('31','28','31','30','31','30','31','31','30','31','30','31');

    //윤년계산
    if(((ny % 4 == 0)&&(ny % 100 !=0)) || (ny % 400 == 0))
        arr_d[1] = 29;

    if(!(Number(dd)) || (nd < 1) || (nd > arr_d[nm-1])) {
        return false;
    }

    return true;
}

/*********************************************************
 * NAME   : gfn_GetCookie(name)
 * DESC   : 쿠키 추출
 * PARAM  : name - 쿠키명
 * RETURN : 쿠키내용
 *
 * 2025.3.28  김동현  최초 작성
 *********************************************************/
function gfn_GetCookie(name) {
    const cookie = `; ${document.cookie}`;
    const parts = cookie.split(`; ${name}=`);
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }
}

/*********************************************************
 * NAME   : gfn_ThisWindowIsPopup()
 * DESC   : 현재 윈도우 팝업 여부 확인
 * RETURN : 현재 윈도우 팝업 여부
 *
 * 2025.4.15  김동현  최초 작성
 *********************************************************/
function gfn_ThisWindowIsPopup() {
    return !!window.name && !gfn_ThisWindowIsIframe();
}

/*********************************************************
 * NAME   : gfn_ThisWindowIsIframe()
 * DESC   : 현재 윈도우 iframe 여부 확인
 * RETURN : 현재 윈도우 iframe 여부
 *
 * 2025.4.15  김동현  최초 작성
 *********************************************************/
function gfn_ThisWindowIsIframe() {
    return gfn_ThisWindowIsTab() || gfn_ThisWindowIsModal();
}

/*********************************************************
 * NAME   : gfn_ThisWindowIsTab()
 * DESC   : 현재 윈도우 탭 여부 확인
 * RETURN : 현재 윈도우 탭 여부
 *
 * 2025.5.21  김동현  최초 작성
 *********************************************************/
function gfn_ThisWindowIsTab() {
    const isMenuTab = !window.name && window.top !== window.self;
    const isDialogTab = window.name.startsWith('tab');
    return isMenuTab || isDialogTab;
}

/*********************************************************
 * NAME   : gfn_ThisWindowIsModal()
 * DESC   : 현재 윈도우 모달 여부 확인
 * RETURN : 현재 윈도우 모달 여부
 *
 * 2025.5.21  김동현  최초 작성
 *********************************************************/
function gfn_ThisWindowIsModal() {
    return window.name.startsWith('modal');
}

/*********************************************************
 * NAME   : gfn_ThisWindowIsTopMain()
 * DESC   : 현재 윈도우의 최상위 여부 확인
 * RETURN : 현재 윈도우의 최상위 여부
 *
 * 2025.4.15  김동현  최초 작성
 *********************************************************/
function gfn_ThisWindowIsTopMain() {
    return !window.name && window.top === window.self;
}

/*********************************************************
 * NAME   : gfn_GetTopMainWindow(_window)
 * DESC   : 최상위 메인 윈도우 획득
 * PARAM  : _window - 윈도우 객체
 * RETURN : 최상위 메인 윈도우
 *
 * 2025.4.15  김동현  최초 작성
 *********************************************************/
function gfn_GetTopMainWindow(_window) {
    if (!_window) _window = window;

    if (!_window.top.name)
        return _window.top;

    if (!_window.top.opener) {
        console.error('parent window is closed');
        window.close();
    }
    return gfn_GetTopMainWindow(_window.top.opener);
}

/*********************************************************
 * NAME   : gfn_CheckIsNumTag(el,type)
 * DESC   : oninput 이벤트시 숫자와 소수점 둘째자리까지만 허용
 * PARAM  : el : input element 객체
 * PARAM  : type : 유형 (1: 정수만, 2: 소수점두자리까지)
 * RETURN : N/A
 *
 * 2025.5.8  장민훈  최초 작성
 *********************************************************/
function gfn_CheckIsNumTag(el,type=1) {
    // 현재 값에서 숫자, 소수점만 허용
    el.value = gfn_GetValidNum(el.value, type);
}

/*********************************************************
 * NAME   : gfn_GetValidNum(val)
 * DESC   : 숫자와 소수점 둘째자리까지만 리턴
 * PARAM  : el : input element 객체
 * PARAM  : type : 유형 (1: 정수만, 2: 소수점두자리까지)
 *
 * 2025.5.8  장민훈  최초 작성
 *********************************************************/
function gfn_GetValidNum(val, type=1) {
    // 현재 값에서 숫자, 소수점만 허용
    let value = val;

    if (type == 1) {
        // 숫자만 남기고 정리(불필요 문자 제거)
        value = value.replace(/[^0-9]/g, '');
    } else if (type == 2) {
        // 숫자와 소수점만 남기고 정리(불필요 문자 제거)
        value = value.replace(/[^0-9.]/g, '');

        // 소수점이 여러 개인 경우 첫번째만 남기기
        const parts = value.split('.');
        if (parts.length > 2) {
            value = parts[0] + '.' + parts[1];
        }

        // 소수점 아래 둘째자리까지만 자르기
        if(parts.length === 2) {
            parts[1] = parts[1].slice(0,2);
            value = parts[0] + '.' + parts[1];
        }
    }

    return value;
}

/*********************************************************
 * NAME   : gfn_FormatDatetime(datetimeInput, format)
 * DESC   : Datetime 문자열 또는 Date 객체를 받아 지정 포맷 문자열로 반환
 * PARAM  : datetimeInput   - [yyyy-MM-dd HH:mm:ss] 형식 문자열 또는 Date 객체
 *          format          - 포맷. e.g. 'yyyy-MM-dd HH:mm:ss'
 *                            기본값: yyyy-MM-dd HH:mm
 * RETURN : 포맷 적용된 문자열
 *
 * 2025.5.13  김동현  최초 작성
 *********************************************************/
function gfn_FormatDatetime(datetimeInput, format = 'yyyy-MM-dd HH:mm') {
    const date = (datetimeInput instanceof Date)
      ? datetimeInput
      : new Date(datetimeInput);

    if (isNaN(date.getTime())) {
        console.log('invalid Date');
        return '';
    }

    const pad = (n) => String(n).padStart(2, '0');

    const map = {
        yyyy: date.getFullYear(),
        MM: pad(date.getMonth() + 1),
        dd: pad(date.getDate()),
        HH: pad(date.getHours()),
        hh: pad((date.getHours() % 12) || 12),
        mm: pad(date.getMinutes()),
        ss: pad(date.getSeconds()),
    };

    return format.replace(/yyyy|MM|dd|HH|hh|mm|ss/g, (token) => map[token]);
}

/*********************************************************
 * NAME   : gfn_SetBodyScroll()
 * DESC   : 화면 내용이 창보다 길 경우 스크롤 생성
 * PARAM  : selector   - 노드 선택자(.className, #idName)
 *
 * 2025.5.19  김동현  최초 작성
 *********************************************************/
function gfn_SetBodyScrollbar({selector = '.popup-main-wrap'} = {}) {
    const popupMainWrap = document.querySelector(selector);
    const scrollHeight = popupMainWrap ? popupMainWrap.scrollHeight : document.body.scrollHeight;

    if (WINDOW_OPTIONS_SCROLLBARS === '0' && (window.innerHeight + 15) >= scrollHeight) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = 'auto';
    }
}

/*********************************************************
 * NAME   : gfn_ResizeWithScroll()
 * DESC   : 대상 노드 또는 body 크기에 맞춰 창 높이 조정
 * PARAM  : selector   - 노드 선택자(.className, #idName)
 *
 * 2025.5.19  김동현  최초 작성
 *********************************************************/
function gfn_ResizeWithScroll({selector = '.popup-main-wrap'} = {}) {
    if (gfn_ThisWindowIsTopMain()) return;

    if (gfn_ThisWindowIsPopup()) {
        const height =
          outerHeight
          - innerHeight
          + document.querySelector(selector).scrollHeight + 3;
        resizeTo(outerWidth, height);

        // TODO 필요 없는 것 아닌가?
        // gfn_SetBodyScrollbar();
    }
    if (gfn_ThisWindowIsModal()) {
        const height =
          parent.document.querySelector('.ui-dialog-titlebar').scrollHeight +
          document.querySelector(selector).scrollHeight + 20;
        parent.gfn_Dialog.modalMap.get(name).dialogPopup('option', 'height', height);
    }
}