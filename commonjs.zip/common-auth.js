/*****************************************************************************
 * SYSTEM : 원전사업관리 시스템
 * NAME   : common-auth.js
 * DESC   : 권한에 따라 사용 불가 버튼 삭제
 * VER    : v1.0
 *****************************************************************************
 *                  변         경         사         항
 *****************************************************************************
 *    DATE     AUTHOR                      DESCRIPTION
 *****************************************************************************
 * 2025.02.17  김동현  최초 프로그램 작성
 *****************************************************************************/

const BTN_AUTH_TYPE_LISTS = {
    ADMIN: ['adminSave', 'adminDelete', 'recreate', 'changeFolder'],
    CREATE: ['new', 'edit', 'save', 'saveTemp', 'send', 'issue', 'delete', 'import', 'export', 'addRow', 'SaveNextStep'],
    DOWNLOAD: ['downloadExcel', 'uploadExcel', 'downloadFileList', 'uploadFile', 'uploadImage'],
    READ: ['detail','print'],
    NONE: ['none'],
};
/*****************************************************************************
 * NAME   : nova.setBtnAuth()
 * DESC   : 권한에 따라 버튼을 숨김 처리 한다.
 * PARAM  : Object {
 *                  writerId    - 콘텐츠 작성자 ID, 필수값 아님
 *                                해당 파라미터 전달시, 로그인 사용자 ID와 비교하여 다를 경우 쓰기 관련 버튼 숨김 처리
 *          }
 * RETURN : void
 *
 * 2025.02.17  김동현  최초 작성
 *****************************************************************************/
function gfn_SetBtnAuth({
                            writerId = '',
                        } = {}) {
    const FULL_LIST = Object.entries(BTN_AUTH_TYPE_LISTS)
      .map(([key, arr]) => arr)
      .reduce((acc, cur) => [...acc, ...cur], []);

    const REMOVE_LISTS = {
        A: [],
        C: [...BTN_AUTH_TYPE_LISTS.ADMIN],
        D: [...BTN_AUTH_TYPE_LISTS.ADMIN, ...BTN_AUTH_TYPE_LISTS.CREATE],
        R: [...BTN_AUTH_TYPE_LISTS.ADMIN, ...BTN_AUTH_TYPE_LISTS.CREATE, ...BTN_AUTH_TYPE_LISTS.DOWNLOAD],
        N: [...BTN_AUTH_TYPE_LISTS.ADMIN, ...BTN_AUTH_TYPE_LISTS.CREATE, ...BTN_AUTH_TYPE_LISTS.DOWNLOAD,
            ...BTN_AUTH_TYPE_LISTS.READ],
    };

    if (writerId && writerId !== CURRENT_USER_ID && USER_MENU_AUTH === 'C') {
        REMOVE_LISTS['D'].forEach(type => document.querySelectorAll(`[data-btn-auth-type=${type}]`)
          .forEach(el => el.remove()));
    } else {
        const removeList = REMOVE_LISTS[USER_MENU_AUTH];

        document.querySelectorAll('button').forEach(el => {
            const btnAuthType = el.dataset.btnAuthType;
            if (FULL_LIST.indexOf(btnAuthType) === -1) {
                console.log('버튼 권한 작성되지 않음. btn id:', el.id, ', data-btn-auth-type:', btnAuthType);
            }
            if (removeList.indexOf(btnAuthType) > -1) {
                el.remove();
            }
        });
    }
}